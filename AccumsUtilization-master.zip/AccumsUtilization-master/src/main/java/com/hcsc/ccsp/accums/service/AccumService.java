package com.hcsc.ccsp.accums.service;

import com.hcsc.ccsp.accums.dto.AccumUtilization;

public interface AccumService {
	
	void updateAccum(AccumUtilization au);

}
