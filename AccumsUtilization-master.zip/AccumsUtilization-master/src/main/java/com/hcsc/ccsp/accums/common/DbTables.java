package com.hcsc.ccsp.accums.common;

public enum DbTables {

    LDGR_HDR,
    LDGR_ENTRY,
    LDGR_SUM;
}
